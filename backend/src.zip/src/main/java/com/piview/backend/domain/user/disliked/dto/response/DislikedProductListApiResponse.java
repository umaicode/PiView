package com.piview.backend.domain.user.disliked.dto.response;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;

@Schema(description = "안 맞는 제품 목록 조회 응답입니다.")
public record DislikedProductListApiResponse(
    @Schema(description = "HTTP 상태 코드입니다.", example = "200")
    int status,

    @Schema(description = "성공 메시지입니다.", example = "요청에 성공했습니다.")
    String message,

    @ArraySchema(
        schema = @Schema(implementation = DislikedProductSummaryResponse.class),
        arraySchema = @Schema(description = "조회된 안 맞는 제품 목록입니다.")
    )
    List<DislikedProductSummaryResponse> data
) {
}

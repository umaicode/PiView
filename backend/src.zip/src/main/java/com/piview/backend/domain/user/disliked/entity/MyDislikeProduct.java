package com.piview.backend.domain.user.disliked.entity;

import com.piview.backend.global.util.BaseEntity;
import com.piview.backend.domain.product.entity.Product;
import com.piview.backend.domain.user.login.entity.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(
    name = "my_dislike_product",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_my_dislike_product_user_product",
            columnNames = {"user_id", "product_id"}
        )
    }
)
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class MyDislikeProduct extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dislike_product_id")
    private Long id;

    // 안 맞는 제품을 등록한 사용자
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // products 테이블은 실제로 product_id 기준으로 식별되므로 PK(id) 기본 참조를 막고 명시적으로 맞춘다.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false, referencedColumnName = "product_id")
    private Product product;
}
